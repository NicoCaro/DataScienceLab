import pandas as pd 

import joblib

from clf_model.config import config
from clf_model import __version__ as _version 

def predict(X):
    name = config.LAST_MODEL_NAME+'_'+str(_version)
    model = joblib.load(config.LAST_MODEL_PATH / name)
    return model.predict(X)
    

if __name__ == '__main__':

    from sklearn.metrics import classification_report
    
    # Se obtienen los datos
    data = pd.read_csv(config.DATA_PATH_TRAIN)

    test_data = data.sample(frac=0.1, random_state=5)
    train_idx = data.index.difference(test_data.index)
        
    # Datos de entrenamiento
    y_train = data.loc[train_idx, config.TARGET]
    x_train = data.drop(config.TARGET, axis=1).loc[train_idx]
    
    # Datos test
    X = test_data.drop(config.TARGET, axis=1)
    y = test_data[config.TARGET]
    
    # Resultados
    c_train = classification_report(predict(x_train),y_train)
    c_test = classification_report(predict(X),y)
    
    print('Score en Train:', c_train) 
    print('Score en Test:', c_test) 
