import  warnings
warnings.filterwarnings("ignore", category=UserWarning)

import numpy as np
import pandas as pd
import joblib

from clf_model import pipeline
from clf_model.config import config 
from clf_model import __version__ as _version 

import logging
_logger = logging.getLogger(__name__)

def clean_old_models(files_to_keep)  :
    '''Limpia los modelos generados en versiones anteriores.'''

    for model_file in config.LAST_MODEL_PATH.iterdir():
        if model_file.name not in [files_to_keep, "__init__.py"]:
            model_file.unlink()


def train(model_name = config.LAST_MODEL_NAME):
    '''Entrena el modelo final.'''

    # Lee los datos
    data = pd.read_csv(config.DATA_PATH_TRAIN)
    test_data = data.sample(frac=0.1, random_state=5)

    train_idx = data.index.difference(test_data.index)

    y_train = data.loc[train_idx, config.TARGET]
    x_train = data.drop(config.TARGET, axis=1).loc[train_idx]
    
    #Entrena el modelo
    pipeline.train_pipe.fit(x_train, y_train)

    name =  model_name+'_'+str(_version) 
    file_name = config.LAST_MODEL_PATH / name 

    #Guarda el modelo y limpia
    _logger.info('Limpiando versiones anteriores')
    clean_old_models(files_to_keep = file_name)

    _logger.info(f"Guardando modelo version: {_version}")
    joblib.dump(pipeline.train_pipe, file_name) 


if __name__ == '__main__':
    train()
