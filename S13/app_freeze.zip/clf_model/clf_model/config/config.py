import pathlib
import clf_model

PACKAGE_ROOT = pathlib.Path(clf_model.__file__).resolve().parent

TARGET = 'Survived'
LAST_MODEL_NAME = 'last_model'

MODELS_PATH  = PACKAGE_ROOT / 'trained_models/'
FINAL_MODEL = MODELS_PATH / 'vote_soft'

LAST_MODEL_PATH = PACKAGE_ROOT / 'last_model/'

DATA_PATH_TRAIN = PACKAGE_ROOT / 'data/train.csv'
DATA_PATH_TEST = PACKAGE_ROOT / 'data/test.csv' 
FAMILY_DICT =PACKAGE_ROOT / 'meta_data/family_dict'

TO_DROP_PIPE = ['Name', 'Parch', 'SibSp', 'Ticket', 'Last_Name', 'PassengerId', 'Embarked', 'Cabin']

FINAL_VARS = ['Pclass','Sex','Age', 'Fare',
              'Family_Survival', 'Title', 'Family_Size']

TEST_VARS = ['PassengerId', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp', 'Parch',
            'Ticket', 'Fare', 'Cabin', 'Embarked']
