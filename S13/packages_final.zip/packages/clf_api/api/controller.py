from flask import Blueprint, request, jsonify

from clf_model.predict import predict
from clf_model import __version__ as _version

from api import __version__ as api_version
from api.config import get_logger

_logger = get_logger(logger_name=__name__)

prediction_app = Blueprint('prediction_app', __name__)

@prediction_app.route('/pred_test', methods=['GET'])
def pred_test():
    if request.method == 'GET':
        _logger.info('Consulta ok')
        return 'test aprobado'

#Se define el endpoint de prediccion
@prediction_app.route('/v1/predict/classify', methods=['POST'])
def predict_classify():
    if request.method == 'POST':
        json_data = request.get_json()
        _logger.info(f'Inputs: {json_data}')

        result = predict(input_data=json_data)
        _logger.info(f'Outputs: {result}')

        predictions = [int(x) for x in result.get('predictions')]
        version = result.get('version')
        
        print('VERSION:',version)
        return jsonify({'predictions': predictions,
                        'version': version})
    
@prediction_app.route('/version', methods=['GET'])
def version():
    if request.method == 'GET':
        return jsonify({'model_version': _version,
                        'api_version': api_version})
