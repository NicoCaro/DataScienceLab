from flask import Flask

#importa la configuracion
from api.config import get_logger

# se comporta igual que el logger del paquete clf_model.
_logger = get_logger(logger_name=__name__)


def create_app(config_object):
    
    flask_app = Flask('clf_api') 
    
    #conecta con la configuracion
    flask_app.config.from_object(config_object)

    #Blueprints 
    from api.controller import prediction_app
    flask_app.register_blueprint(prediction_app)
    _logger.debug('Instancia de App creada')

    return flask_app
