import pandas as pd 
import numpy as np 

from clf_model.predict import predict
from clf_model.config import config 

def test_predict_tails():
    
    test_data = pd.read_csv(config.DATA_PATH_TEST)
    
    json_1 = test_data.iloc[0].to_json(orient='index')
    json_2 = test_data.iloc[-1].to_json(orient='index')

    subject_1 = predict(input_data=json_1)
    subject_2 = predict(input_data=json_2)

    
    assert any((subject_1,subject_2)) is not None 
    print(type(subject_1.get('predictions')[0]))
    
    assert isinstance(subject_1.get('predictions')[0], np.int64)
    assert isinstance(subject_2.get('predictions')[0], np.int64)
    
    assert subject_1.get('predictions')[0] == 0
    assert subject_2.get('predictions')[0] == 1
