import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import StandardScaler, KBinsDiscretizer
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder

from clf_model.config import config

class NaMeanFiller(BaseEstimator, TransformerMixin):
    '''Cambia los datos faltantes de la columna col por la media en df.'''

    def __init__(self, col='Fare', mean=None):
        self.col = col
        self.mean = mean

    def fit(self, X, y=None):
        if self.mean is None:
            data = X.copy()
            self.mean = data[self.col].mean()

        return self

    def transform(self, X):
        data = X.copy()
        
        if type(data[self.col]) is not pd.core.series.Series: 
            data[self.col] = self.mean
        else:
            data[self.col].fillna(self.mean, inplace=True)

        return data

class LastNameGen(BaseEstimator, TransformerMixin):
    '''Genera la columna Last_name a partir de Name en el DataFrame df.'''

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        data = X.copy()
        
        if type(data['Name']) is not pd.core.series.Series: 
            data['Last_Name'] = data['Name'].split(",")[0]
        else:
            data['Last_Name'] = data['Name'].apply(lambda x: str.split(x, ",")[0])
        

        return data

class FamilySurvivalGen(BaseEstimator, TransformerMixin):

    '''Recibe observaciones y asigna probabilidad de supervivencia por familia.

    Permite generar una variable donde se asigna una proporcion de sobrevivencia
    por familia. Para ello toma un DataFrame con las relaciones por familia si
    el apellido asociado a la observacion x en df esta en el conjunto  de
    familias, le asigna el valor indicado en family_dict. En caso contrario
    le asigna la probabilidad default_prob.

    '''

    def __init__(self, default_prob=.5, family_dict=None):

        self.default_prob = default_prob
        self.family_dict = family_dict

    def fit(self, X, y=None):
        '''Genera un DataFrame con probabilidades de supervivencia por familia.

        El conjunto de datos debe tener las columnas: Survived, Name, Last_Name, 
        Fare, Ticket, PassengerId, SibSp, Parch, Age y Cabin. Se genera un  
        DataFrame con la relación familia -> fecuencia de supervivenca.

        Retorna:
        --------

        data: Pandas.DataFrame
            Un conjunto con la relacion familia - frecuencia de supervivencia
        '''

        if self.family_dict is None:

            data = X.copy()

            # Utiliza un valor prior para la probabilidad de sobrevivir
            data['Family_Survival'] = self.default_prob

            # Se agrupa el conjunto de datos por apellido y fare
            for grp, grp_df in data[['Survived', 'Name', 'Last_Name', 'Fare',
                                     'Ticket', 'PassengerId',
                                     'SibSp', 'Parch', 'Age',
                                     'Cabin']].groupby(['Last_Name', 'Fare']):

                # Si no es igual a 1, se encuentra una familia
                # en tal caso se calcula una probabilidad de supervivencia
                if (len(grp_df) != 1):
                    for ind, row in grp_df.iterrows():
                        smax = grp_df.drop(ind)['Survived'].max()
                        smin = grp_df.drop(ind)['Survived'].min()
                        passID = row['PassengerId']
                        if (smax == 1.0):
                            data.loc[data['PassengerId'] ==
                                     passID, 'Family_Survival'] = 1
                        elif (smin == 0.0):
                            data.loc[data['PassengerId'] ==
                                     passID, 'Family_Survival'] = 0

            # Luego se agrupa la informacion por tickets y se procede
            for _, grp_df in data.groupby('Ticket'):
                if (len(grp_df) != 1):
                    for ind, row in grp_df.iterrows():
                        if (row['Family_Survival'] == 0) | (row['Family_Survival'] == 0.5):
                            smax = grp_df.drop(ind)['Survived'].max()
                            smin = grp_df.drop(ind)['Survived'].min()
                            passID = row['PassengerId']
                            if (smax == 1.0):
                                data.loc[data['PassengerId'] ==
                                         passID, 'Family_Survival'] = 1
                            elif (smin == 0.0):
                                data.loc[data['PassengerId'] ==
                                         passID, 'Family_Survival'] = 0

            self.family_dict = data.groupby('Last_Name').mean()[
                'Family_Survival']
        else:
            return self

    def transform(self, X):

        data = X.copy()
        data['Family_Survival'] = self.default_prob

        if self.family_dict is not None:
            if type(data) is not pd.core.series.Series: 

                for x in data.itertuples():
                    if x.Last_Name in self.family_dict:
                        prob = self.family_dict.loc[x.Last_Name]
                        data.loc[data['PassengerId'] ==
                                 x.PassengerId, 'Family_Survival'] = prob
                return data

            else:
                
                if data['Last_Name'] in self.family_dict:
                    prob = self.family_dict.loc[data['Last_Name']]
                    data['Family_Survival'] = prob

                return data

        else:
            print('Inicializar diccionario de familias antes de transformar!')


class ColToCat(BaseEstimator, TransformerMixin):
    '''Toma un conjunto de datos df y transfroma la columna col en categorica.

    La cantidad de bins viene dada por el parametro cuts.'''

    def __init__(self, col='Fare', cuts=4):
        self.col = col
        self.cutter = KBinsDiscretizer(n_bins=cuts, encode='ordinal', strategy='quantile')

    def fit(self, X, y=None):
        data = X.copy()
        self.cutter.fit(data[self.col].values.reshape([-1, 1]))
        
        return self

    def transform(self, X):
        data = X.copy()

        if type(data[self.col]) is pd.core.series.Series: 
            data[self.col] = self.cutter.transform(data[self.col].values.reshape([-1, 1]))
        else:
            data[self.col] = self.cutter.transform(np.array(data[self.col]).reshape([-1,1]))[0][0]
        return data


class TitleGen(BaseEstimator, TransformerMixin):

    def get_title(self, name):
        '''Obtiene le titulo asociado a una persona.'''

        if '.' in name:
            return name.split(',')[1].split('.')[0].strip()
        else:
            return 'desconocido'

    def set_title(self, x):
        '''Reduce el titulo a Mr,Mrs o Miss segun corresponda.'''

        title = x['Title']
        if title in ['Capt', 'Col', 'Don', 'Jonkheer', 'Major', 'Rev', 'Sir']:
            return 'Mr'
        elif title in ['the Countess', 'Mme', 'Lady', 'Dona']:
            return 'Mrs'
        elif title in ['Mlle', 'Ms']:
            return 'Miss'
        elif title == 'Dr':
            if x['Sex'] == 'male':
                return 'Mr'
            else:
                return 'Mrs'
        else:
            return title

    def fit(self, X, y=None):
        return self

    def transform(self, X):

        data = X.copy()

        if type(data['Name']) is not pd.core.series.Series: 
            data['Title'] = self.get_title(data['Name'])
            data['Title'] = self.set_title(data)
        else:
            data['Title'] = data['Name'].map(lambda x: self.get_title(str(x)))
            data['Title'] = data.apply(self.set_title, axis=1)

        return data
    
class AgeImputer(BaseEstimator, TransformerMixin):   
    
    def __init__(self, title_map = None):
        self.title_map = title_map
        
    def fit(self, X, y=None):
        
        if self.title_map is None:
            data = X.copy()
            self.title_map = data.groupby('Title')['Age'].apply(lambda x: x.median())
        
        return self

    def transform(self, X):
        ''' Llena la información faltante de la columna Age en df. 

        Utiliza una agrupacion por titulo y aplica un llenado por mediana de grupo.

        Retorna:
        -------- 

        data: Pandas.DataFrame 
            Conjunto de datos con la variable Age completada.
        '''
        data = X.copy()
        if type(data['Age']) is not pd.core.series.Series:
            if data.isnull()['Age'].any(): data['Age'] = self.title_map.loc[data['Title']]
                
        else:
            data.loc[data['Age'].isnull(), 'Age'] = data['Title'].map(self.title_map)
            

        return data

class ModeFill(BaseEstimator, TransformerMixin):

    def __init__(self, col, mode = None):
        
        self.col = col
        self.mode = mode 
    
    def fit(self, X, y=None):
        
        if self.mode is None:
            data = X.copy()
            self.mode = data[self.col].mode()[0]
        return self

    def transform(self, X):
        '''Llena los valores faltantes de col en df usando la moda global.

        Retorna: 
        -------- 

        data: Pandas.DataFrame 
            Conjunto de datos con la informacion de col completada. 
        '''

        data = X.copy()
        if type(data[self.col]) is pd.core.series.Series:
            data[self.col] = data[self.col].fillna(self.mode)
        else:
            if data.isnull()[self.col].any(): data[self.col] = self.mode

        return data


class FillDesconocido(BaseEstimator, TransformerMixin):
    def __init__(self, col):
        self.col = col

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        ''' Toma un conjunto de datos df y llena la columna col con el valor
        'desconocido'.

        Retorna:
        -------- 

        data : Pandas.DataFrame
            Conjunto de datos con la variable col completada. 

        '''
        data = X.copy()
        if type(data[self.col]) is pd.core.series.Series:
            data[self.col].fillna('desconocido', inplace=True)
        else:
            if data.isnull()[self.col].any(): data[self.col] = 'desconocido'

        return data


class CabinCat(BaseEstimator, TransformerMixin):

    def unknown_cabin(self, cabin):
        if cabin != 'd':
            return 1
        else:
            return 0

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        '''Genera dos categorias en df basandose en la columna Cabin.

        Retorna:
        -------

        data : Pandas.DataFrame 
            Conjunto de datos con la categorizacion creada. 
        '''

        data = X.copy()
        if type(data['Cabin']) is pd.core.series.Series:
            data['Cabin'] = data['Cabin'].map(lambda x: x[0])
            data['Cabin'] = data['Cabin'].apply(lambda x: self.unknown_cabin(x))
        else:
            data['Cabin'] = data['Cabin'][0]
            data['Cabin'] = self.unknown_cabin(data['Cabin'])

        return data


class FamilySizeGen(BaseEstimator, TransformerMixin):

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        '''Genera la columna Family_Size a partir de SibSp y Parch en df. 

        Retorna:
        ------- 
        data : Pandas.DataFrame 
            Conjunto de datos con la columna creada. 

        '''
        data = X.copy()
        data['Family_Size'] = data['SibSp'] + data['Parch']

        return data


class OneHotEncoderCol(BaseEstimator, TransformerMixin):

    def __init__(self, col='Sex'):
        self.col = col
        self.ohe = OneHotEncoder(sparse=False)

    def fit(self, X, y=None):
        data = X.copy()
        self.ohe.fit(data[self.col].values.reshape([-1, 1]))
        return self

    def transform(self, X):
        '''Genera codificacion One hot en df basandose en la columna col.

        Retorna:
        -------

        data : Pandas.DataFrame
            Conjunto de datos con el encoding creado.
        '''
        data = X.copy()
        
        
        if type(data[self.col]) is pd.core.series.Series:
            data[self.col] = self.ohe.transform(data[self.col].values.reshape([-1, 1]))

        else: 
            val = np.array(data[self.col]).reshape([-1,1])
            data[self.col] = self.ohe.transform(val)[0][0]
        
        return data


class OrdinaltEncoderCol(BaseEstimator, TransformerMixin):

    def __init__(self, col='Title'):
        self.col = col
        self.ode = OrdinalEncoder()

    def fit(self, X, y=None):
        
        data = X.copy()
        self.ode.fit(data[self.col].values.reshape([-1, 1]))
        
        return self
    

    def transform(self, X):
        '''Genera codificacion Ordinal df basandose en la columna col.

        Retorna:
        -------

        data : Pandas.DataFrame 
            Conjunto de datos con el encoding creado. 
        '''

        data = X.copy()
        
        if type(data[self.col]) is pd.core.series.Series:
            data[self.col] = self.ode.transform(data[self.col].values.reshape([-1, 1]))

        else: 
            val = np.array(data[self.col]).reshape([-1,1])
            data[self.col] = self.ode.transform(val)[0][0]
        
        return data


class DropCols(BaseEstimator, TransformerMixin):

    def __init__(self, cols=config.TO_DROP_PIPE):
        self.cols = cols

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        '''Elimina las columans cols del DataFrame df.


        Retorna:
        --------
        data : Pandas.DataFrame 
            Conjunto de datos con las columnas borradas. 

        '''

        data = X.copy()
        if type(data) is pd.core.frame.DataFrame:
            data.drop(self.cols, axis=1, inplace=True)
        else:
            data.drop(self.cols, inplace=True)
            
        return data


class StdScaler(BaseEstimator, TransformerMixin):
    
    def __init__(self):
        self.std_scaler = StandardScaler()

    def fit(self, X, y=None):
        data = X.copy()
        self.std_scaler.fit(data)
        
        return self

    def transform(self, X):
        '''Toma un DataFrame y lo estandariza, retorna un DataFrame.'''

        data = X.copy()
        
        if type(data) is pd.core.frame.DataFrame:
            cols = data.columns
            res = self.std_scaler.transform(data)
            return  pd.DataFrame(res, columns=cols)
        
        else:
            cols = data.index
            res = self.std_scaler.transform(data.values.reshape([1,-1]))
            return pd.Series(data = res[0], index=cols) 
