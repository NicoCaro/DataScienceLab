import pandas as pd 

import joblib

from clf_model.config import config

def predict(X):
    
    model = joblib.load(config.LAST_MODEL_PATH + config.LAST_MODEL_NAME)
    
    return model.predict(X)
    

if __name__ == '__main__':

    from sklearn.metrics import classification_report
    
    # Se obtienen los datos
    data = pd.read_csv(config.DATA_PATH_TEST)

    # Datos test
    X = pd.DataFrame(data.iloc[-1]).T  
    
    # Resultados
    
    print(predict(X))
