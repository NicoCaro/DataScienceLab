import  warnings
warnings.filterwarnings("ignore", category=UserWarning)

import pandas as pd 
import joblib

from clf_model.config import config 
from clf_model import __version__ as _version 

import logging

_logger = logging.getLogger(__name__)

def predict(input_data):
    '''Predice utilizando el modelo entrenado.''' 
    name =  config.LAST_MODEL_NAME + '_' +str(_version)
    model = joblib.load(config.LAST_MODEL_PATH / name)
    
    data = pd.read_json(input_data, orient='index')
    
    if data.shape[1] == 1:

        output = model.predict(pd.DataFrame(data).T)
        _logger.info(
            f"Version del modelo: {_version} "
            f"Inputs para predecir: {data} "
            f"Predicciones: {output}"
        )

    else:
        output = model.predict(data)
        _logger.info(
            f"Version del modelo: {_version} "
            f"Inputs para predecir: {data} "
            f"Predicciones: {output}"
        )


    response = {"predictions": output, "version":_version}
    
    return response
