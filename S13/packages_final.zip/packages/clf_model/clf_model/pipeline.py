import joblib

from clf_model.config import config 
from clf_model.processing import preprocesssors as pp

from sklearn.pipeline import Pipeline

family_dict = joblib.load(config.FAMILY_DICT)
model = joblib.load(config.FINAL_MODEL)

train_pipe = Pipeline([
    ('Fare mean fill',pp.NaMeanFiller()),
    ('Last_Name gen',pp.LastNameGen()),
    ('Family_Survival gen', pp.FamilySurvivalGen(family_dict=family_dict)),
    ('Fare to cat', pp.ColToCat()),
    ('Title var gen', pp.TitleGen()),
    ('Age imputer', pp.AgeImputer()),
    ('Age to cat', pp.ColToCat(col='Age')),
    ('Title to ordinal', pp.OrdinaltEncoderCol()),
    ('Sex to One Hot Enc', pp.OneHotEncoderCol()),
    ('Fill with the mode Embarked', pp.ModeFill(col='Embarked')),
    ('Embarked to Ordinal', pp.OrdinaltEncoderCol(col='Embarked')),
    ('Fill desconocido Cabin',pp.FillDesconocido(col='Cabin')),
    ('Cabin to Cat', pp.CabinCat()),
    ('Family size gen', pp.FamilySizeGen()),
    ('drop cols',pp.DropCols(cols = config.TO_DROP_PIPE)),
    ('Scaler', pp.StdScaler()),
    ('clf', model)
    ])
